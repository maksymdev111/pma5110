DESCRIPTION:
This example lets the user remotely control the RGB LEDs on the White LED
Card with a PMAfob remote controller.

REQUIREMENTS:
- J-Link Drivers installed on PC
- J-Link v4.59 or above
- inLight White LED Card
- XMC1200 Boot Kit
- PMAfob wireless remote control transmitter: www.infineon.com/pmafob
- PMA Starter Kit to program the PMAfob: www.infineon.com/pma_starterkit

IMPORTANT:
- R104 must be desoldered on the Boot Kit

SETUP:
1. Connect inLight Colour LED Card to XMC1200 Boot Kit
2. Desolder R104 from the Boot Kit (this is the resistor next to the P00
   LED) 
3. Program PMAfob (see below)
4. Connect XMC1200 Boot Kit to USB

HOW TO CREATE THE XMC1000 PROJECT:
1) Create a new Empty Main Project.
2) Set MCLK to 32MHz and PCLK to 64MHz.
3) Enable pins P0.5, P0.6, P0.7 and P0.8 as BCCU outputs.
5) Enable clock to BCCU
6) Initialise BCCU
   - 4 channels
   - 1 dimming engine
7) Initialise CCU4 slice 0 for edge detection
8) Initialise Systick. Create SysTick interrupt handler for button time out
   measurement.
9) Create CCU4 slice 0 edge detection interrupt, decode the messages, dim
   and mix colors accordingly. 

OBSERVATIONS:
1. Middle button on PMAFOB turns the LEDs on and off
2. Top button increases the dimming level
3. Bottom button decreases the dimming level
4. Left button increases the brightness of the bottom two LED rows and
   decreases the brightness of the top two LED rows
5. Right button increases the brightness of the top two LED rows and
   decreases the brightness of the bottom two LED rows

HOW TO PROGRAM THE PMAFOB:
1. Download and install Keil C51 uVISION4
2. Download and install PMA STARTER KIT SOFTWARE
   - Go to www.infineon.com/pma_starterkit and download the PMA Starter Kit
     SW package (PMA_STARTER_KIT_SW_Vx.y.zip). It is under the “Development
     Tools & Software” tab.
   - Start PMA_STARTER_KIT_Setup_Vx.y.msi to integrate the PMA product
     family into Keil C51 uVISION4.
   - Start PMA_Software_Framework_Vx.y.msi to install the PMA Software
     Framework with typical coding examples.  
   - You will need .Net Framework 1.1 installed on your PC.
3. Import and download the transmission program (attached
   PMAfob Software Example_unencrypted.zip).
   - Open the transmission program in uVISION4.
   - Right click on the project title and select “Options for Target
     ‘xxxxx’…”.
   - Under the device tab, change Database from “Generic CPU Data Base” to
     “Infineon PMA Device List”. Choose PMA5110.
   - Exit “Options for Target ‘xxxxx’…” window, right click and choose
     “Add Group…” to add and manage source files (.c/ .a51), header files
     (.h) and file groups. Typically following files being part of the PMA
     Software Framework must be added to a PMA Software Project: 
       STARTUP_PMA71xx_PMA51xx.A51, Reg_PMA71xx_PMA51xx.h,
       PMA71xx_PMA51XX_Library.h, PMA71xx_PMA51xx_Library.LIB.
   - Adjust the settings for your project: Right click on the transmission
     program and choose “Options for Target”.
   - Under the “Target” tab select On-chip ROM (Flash memory) for code
     development.
   - Under the “Output” tab, select to create a hex file and assign a
     name to it.
   - Under the “Debug” tab,  select “Infineon PMA Starter Kit Driver”.
   - Click the “Settings” button, check “Use Real-time debugging” and “Use
     GPIO Connector”.
   - Under the “Utilities” tab, select “Infineon PMA Starter Kit Driver”.
   - Click the “Settings” button, select “Use Project Hex File” and check
     “Use GPIO Connector”, “Erase Flash”, “Code Sector”, “Use Data Sector
     I”, “Use Data Sector II”, “Program Flash”, “Verify Flash” and “Run
     after Download (Normal Mode)”.
   - Click “OK” on the “Options for Target ‘xxxx’…” window and start
     download.
   
   
HOW TO CONNECT PMA RF USB STICK (programmer) TO PMAFOB (connector X5):

   Pin #  Signal name    IC pin #  Signal name         
   1      PP2                      PP0 (I2C clock)
   2      PP3                      PP1 (I2C data)
   3      PP4                      xReset (reset)
   4      PP5                      MSE (mode select enable)
   5      VBAT           NC        n.a.
   6      GNDA                     GND
   
   - Take a look at attached PMAfob_programming.png   
   