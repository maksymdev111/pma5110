XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
X   Artwork and documentation done by: Texas Instruments Norway AS              X
X   Company: Texas Instruments Norway AS                                        X
X   Address: Gaustadall�en 21    0349 OSLO                                      X
X                                                                               X
X                                                                               X
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

PCB NAME : CC1110EM 315MHz
REVISION: 2.0.0 (PCB 2.0.0, Schematic 2.0.0)
DATE: 2009-09-20


Manufacturers marking: Two letter + year + week
The two letter code shall identify the manufaturer and is decided by the manufacturer. 
No logos or other identifiers are allowed.
The marking shall be in silk screen print at secondary side of the PCB, or in solder 
resist if no silk print at secondary side.

FILE: CC1110EM_315MHz_REFERENCE_DESIGN_2_0_0.ZIP PACKED WITH WinZIP V.9.0 

PCB DESCRIPTION: 2 LAYER PCB 0.8 MM NOMINAL THICKNESS FR4
                 Dimensions in mil (0.001 inch)
                 DOUBLE SIDE SOLDER MASK,
                 DOUBLE SIDE SILKSCREEN,
                 8 MIL MIN TRACE WIDTH AND 8 MIL MIN ISOLATION
                 Dielectric constant for FR4 is 4.5


                 
FILE NAME            		DESCRIPTION                               	FILE TYPE
-------------------------------------------------------------------------------------------
***PCB MANUFACTURING FILES:
l1.SPL                  LAYER 1 COMPONENT SIDE/POSITIV              EXT. GERBER
l2.SPL                  LAYER 2 Inner layer/POSITIV                 EXT. GERBER

STOPCOMP.SPL            SOLDER MASK COMPONENT SIDE/NEGATIVE         EXT. GERBER
STOPSOLD.SPL            SOLDER MASK SOLDER SIDE/NEGATIVE            EXT. GERBER

SILKCOMP.SPL            SILKSCREEN COMPONENT SIDE/POSITIVE          EXT. GERBER
SILKSOLD.SPL            SILKSCREEN SOLDER SIDE/POSITIVE             EXT. GERBER

PASTCOMP.SPL            SOLDER PAST COMPONENT SIDE/POSITIVE         EXT. GERBER
PATSOLD.SPL             SOLDER PAST SOLDER SIDE/POSITIVE            EXT. GERBER

ASSYCOMP.SPL            ASSEMBLY DRAWING COMPONENT SIDE					    EXT. GERBER
ASSYSOLD.SPL            ASSEMBLY DRAWING SOLDER SIDE				|       EXT. GERBER

NCDRILL.SPL             NC DRILL THROUGH HOLE                       EXCELLON
DRILL.SPL               DRILL/MECHANICAL DRAWING                    EXT. GERBER

GERBER.REP              DRILL/NC DRILL REPORT                       ASCII

P&PCOMP.REP             PICK AND PLACE FILE COMPONENT SIDE          ASCII
P&PSOLD.REP             PICK AND PLACE FILE SOLDER SIDE             ASCII

EXT_GERBER.USR          EXTENDED GERBER APERTURE TABLE              ASCII
CNC.USR                 NC DRILL DEVICE FILE                        ASCII

CC1110EM_315MHz_PARTLIST_2_0_0.xls	Partlist

***PDF FILES:
CC1110EM_315MHz_SCHEMATIC_2_0_0.PDF					Circuit Diagram
CC1110EM_315MHz_LAYOUT_2_0_0.PDF						Layout Diagram

***CADSTAR FILES:
CC1110EM_315MHz_2_0_0.SCM										Cadstar Schematic file
CC1110EM_315MHz_2_0_0.CSA										Cadstar Shematic archive
CC1110EM_315MHz_2_0_0.PCB										Cadstar layout file
CC1110EM_315MHz_2_0_0.CPA										Cadstar PCB archive

README.TXT              THIS FILE                                   ASCII




***REVISION HISTORY
Rev 1.2
Rev 1.3  Added RC filter close to RESETn pin (pin 31)
Rev 2.0.0 Changed crystal size to 3.2x2.5 mm 
					Changed crystal loading capacitors C211 and C201 to 12 pF and 15 pF respectively
					Removed ground connections on P2 connector (except for P2.2)  

END.
