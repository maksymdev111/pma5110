/*******************************************************************************
 Copyright (c) 2016, Infineon Technologies AG                                 **
 All rights reserved.                                                         **
                                                                              **
 Redistribution and use in source and binary forms, with or without           **
 modification,are permitted provided that the following conditions are met:   **
                                                                              **
 *Redistributions of source code must retain the above copyright notice,      **
 this list of conditions and the following disclaimer.                        **
 *Redistributions in binary form must reproduce the above copyright notice,   **
 this list of conditions and the following disclaimer in the documentation    **
 and/or other materials provided with the distribution.                       **
 *Neither the name of the copyright holders nor the names of its contributors **
 may be used to endorse or promote products derived from this software without**
 specific prior written permission.                                           **
                                                                              **
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"  **
 AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE    **
 IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE   **
 ARE  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE   **
 LIABLE  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR         **
 CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF         **
 SUBSTITUTE GOODS OR  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS    **
 INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN      **
 CONTRACT, STRICT LIABILITY,OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)       **
 ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE   **
 POSSIBILITY OF SUCH DAMAGE.                                                  **
                                                                              **
 To improve the quality of the software, users are encouraged to share        **
 modifications, enhancements or bug fixes with Infineon Technologies AG       **
 dave@infineon.com).                                                          **
                                                                              **
********************************************************************************
**                                                                            **
**                                                                            **
** PLATFORM : Infineon XMC1200 Series                                         **
**                                                                            **
** AUTHOR : Application Engineering Team                                      **
**                                                                            **
** version 1.0.0 (Initial version)			                                  **
** version 2.0.0 (Migration to DAVE v4)		                                  **
**                                                                            **
** MODIFICATION DATE : Jul, 25, 2016                                          **
**                                                                            **
*******************************************************************************/

/*********************************************************************************************************************
 * HEADER FILES
 ********************************************************************************************************************/
#include <xmc_gpio.h>
#include <xmc_bccu.h>
#include <xmc_ccu4.h>
#include <xmc_ccu4_map.h>

/*********************************************************************************************************************
 * MACROS
 ********************************************************************************************************************/
#define ON  1
#define OFF 0

#define R_LED1 P0_4
#define G_LED1 P0_11
#define B_LED1 P0_1

#define R_LED2 P0_5
#define G_LED2 P0_6
#define B_LED2 P0_7

#define R_LED3 P0_8
#define G_LED3 P0_9
#define B_LED3 P0_10

#define LINEAR_WALK_PRESCALER 0x10 /* 32ms walk time */

/*********************************************************************************************************************
 * GLOBAL VARIABLES
 ********************************************************************************************************************/
uint32_t TimerCount;
uint8_t  packet;
uint32_t dimlv;
uint32_t dimlvbuf;
uint8_t  colornumber = 0;

uint16_t colorArrayR[] = {
  0xFFF, 0xE00, 0xC00, 0xA00, 0x800, 0x600, 0x400, 0x200,
  0x000, 0x000, 0x000, 0x000, 0x000, 0x000, 0x000, 0x000,
  0x000, 0x200, 0x400, 0x600, 0x800, 0xA00, 0xC00, 0xE00
};

uint16_t colorArrayG[] = {
  0x000, 0x200, 0x400, 0x600, 0x800, 0xA00, 0xC00, 0xE00,
  0xFFF, 0xE00, 0xC00, 0xA00, 0x800, 0x600, 0x400, 0x200,
  0x000, 0x000, 0x000, 0x000, 0x000, 0x000, 0x000, 0x000
};

uint16_t colorArrayB[] = {
  0x000, 0x000, 0x000, 0x000, 0x000, 0x000, 0x000, 0x000,
  0x000, 0x200, 0x400, 0x600, 0x800, 0xA00, 0xC00, 0xE00,
  0xFFF, 0xE00, 0xC00, 0xA00, 0x800, 0x600, 0x400, 0x200
};

int newframe;
int bitend;
int bitnumber;
int count;
int state;

/*********************************************************************************************************************
 * CONFIGURATIONS
 ********************************************************************************************************************/
/* Clock configuration */
XMC_SCU_CLOCK_CONFIG_t clock_config =
{
  .pclk_src = XMC_SCU_CLOCK_PCLKSRC_DOUBLE_MCLK,
  .fdiv = 0,
  .idiv = 1
};

/* BCCU Configuration Handles */
/* --------------------------- */
XMC_BCCU_GLOBAL_CONFIG_t bccu_global_config =
{
  .fclk_ps = 0xC8, //320kHz @PCLK=64MHz
  .dclk_ps = 0xdb, //292.237kHz @PCLK=64MHz
  .bclk_sel = XMC_BCCU_BCLK_MODE_NORMAL, //250KHz @PCLK=64MHz
  .maxzero_at_output = 0xFF
};

XMC_BCCU_CH_CONFIG_t bccu_pdm_ch_config =
{
  .pack_thresh     = 0x2,
  .pack_en         = 0x1,
  .dim_sel         = 0x0, //DE0
  .flick_wd_en     = 0x0
};

XMC_BCCU_DIM_CONFIG_t bccu_dim_config =
{
  .cur_sel = XMC_BCCU_DIM_CURVE_FINE,
  .dim_div = 0x00 //immediate dimming
};

/* Configuration for CCU4 slice external event */
XMC_CCU4_SLICE_EVENT_CONFIG_t slice_event_config0 =
{
  .mapped_input	= CCU40_IN0_P0_0, /**< input signal that will trigger this event */
  .edge		= XMC_CCU4_SLICE_EVENT_EDGE_SENSITIVITY_RISING_EDGE, /**< trigger on rising edge */
  .duration	= XMC_CCU4_SLICE_EVENT_FILTER_DISABLED /**< disable filter */
};

XMC_CCU4_SLICE_EVENT_CONFIG_t slice_event_config1 =
{
  .mapped_input	= CCU40_IN0_P0_0, /**< input signal that will trigger this event */
  .edge		= XMC_CCU4_SLICE_EVENT_EDGE_SENSITIVITY_FALLING_EDGE, /**< trigger on falling edge */
  .duration	= XMC_CCU4_SLICE_EVENT_FILTER_DISABLED /**< disable filter */
};

XMC_CCU4_SLICE_CAPTURE_CONFIG_t capture_event_config =
{
  .fifo_enable = 0,
  .timer_clear_mode = XMC_CCU4_SLICE_TIMER_CLEAR_MODE_ALWAYS,
  .same_event = 0,
  .ignore_full_flag = 0,
  .prescaler_mode = XMC_CCU4_SLICE_PRESCALER_MODE_NORMAL,
  .prescaler_initval = 0x1
};

/**

 * @brief main() - Application entry point
 *
 * <b>Details of function</b><br>
 * This routine is the application entry point. It is invoked by the device startup code. 
 */

int main(void)
{
  //----CLOCK-SETUP-----------------------------------------------------------------------------------
  XMC_SCU_CLOCK_Init(&clock_config);
  //--------------------------------------------------------------------------------------------------

  /* initialize PDM output pins */
  XMC_GPIO_SetMode(R_LED1, XMC_GPIO_MODE_OUTPUT_PUSH_PULL_ALT1);
  XMC_GPIO_SetMode(G_LED1, XMC_GPIO_MODE_OUTPUT_PUSH_PULL_ALT1);
  XMC_GPIO_SetMode(B_LED1, XMC_GPIO_MODE_OUTPUT_PUSH_PULL_ALT6);
  XMC_GPIO_SetMode(R_LED2, XMC_GPIO_MODE_OUTPUT_PUSH_PULL_ALT1);
  XMC_GPIO_SetMode(G_LED2, XMC_GPIO_MODE_OUTPUT_PUSH_PULL_ALT1);
  XMC_GPIO_SetMode(B_LED2, XMC_GPIO_MODE_OUTPUT_PUSH_PULL_ALT1);
  XMC_GPIO_SetMode(R_LED3, XMC_GPIO_MODE_OUTPUT_PUSH_PULL_ALT1);
  XMC_GPIO_SetMode(G_LED3, XMC_GPIO_MODE_OUTPUT_PUSH_PULL_ALT1);
  XMC_GPIO_SetMode(B_LED3, XMC_GPIO_MODE_OUTPUT_PUSH_PULL_ALT1);

  /* 0.01s timer interrupt assuming that SystemCoreClock is 32 MHz (default) */
  SysTick_Config(SystemCoreClock / 100U);

  /* BCCU Configuration */
  XMC_BCCU_GlobalInit(BCCU0, &bccu_global_config);

  /* LED1: Red - CH0, Green - CH7, Blue - CH8 */
  XMC_BCCU_CH_Init(BCCU0_CH0, &bccu_pdm_ch_config);
  XMC_BCCU_CH_Init(BCCU0_CH7, &bccu_pdm_ch_config);
  XMC_BCCU_CH_Init(BCCU0_CH8, &bccu_pdm_ch_config);
  /* LED2: Red - CH1, Green - CH2, Blue - CH3 */
  XMC_BCCU_CH_Init(BCCU0_CH1, &bccu_pdm_ch_config);
  XMC_BCCU_CH_Init(BCCU0_CH2, &bccu_pdm_ch_config);
  XMC_BCCU_CH_Init(BCCU0_CH3, &bccu_pdm_ch_config);
  /* LED3: Red - CH4, Green - CH5, Blue - CH6 */
  XMC_BCCU_CH_Init(BCCU0_CH4, &bccu_pdm_ch_config);
  XMC_BCCU_CH_Init(BCCU0_CH5, &bccu_pdm_ch_config);
  XMC_BCCU_CH_Init(BCCU0_CH6, &bccu_pdm_ch_config);

  /* Set 32ms linear walk */
  XMC_BCCU_CH_SetLinearWalkPrescaler(BCCU0_CH0, LINEAR_WALK_PRESCALER);
  XMC_BCCU_CH_SetLinearWalkPrescaler(BCCU0_CH7, LINEAR_WALK_PRESCALER);
  XMC_BCCU_CH_SetLinearWalkPrescaler(BCCU0_CH8, LINEAR_WALK_PRESCALER);
  XMC_BCCU_CH_SetLinearWalkPrescaler(BCCU0_CH1, LINEAR_WALK_PRESCALER);
  XMC_BCCU_CH_SetLinearWalkPrescaler(BCCU0_CH2, LINEAR_WALK_PRESCALER);
  XMC_BCCU_CH_SetLinearWalkPrescaler(BCCU0_CH3, LINEAR_WALK_PRESCALER);
  XMC_BCCU_CH_SetLinearWalkPrescaler(BCCU0_CH4, LINEAR_WALK_PRESCALER);
  XMC_BCCU_CH_SetLinearWalkPrescaler(BCCU0_CH5, LINEAR_WALK_PRESCALER);
  XMC_BCCU_CH_SetLinearWalkPrescaler(BCCU0_CH6, LINEAR_WALK_PRESCALER);

  XMC_BCCU_DIM_Init(BCCU0_DE0, &bccu_dim_config);

  /* Enable RGB channels, dimming engine */
  XMC_BCCU_ConcurrentEnableChannels(BCCU0, 0x1FF);
  XMC_BCCU_EnableDimmingEngine(BCCU0, XMC_BCCU_CH_DIMMING_SOURCE_DE0);

  /* Set all 3 LEDs to RED at start */
  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH0, 0xFFF);
  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH7, 0x0);
  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH8, 0x0);
  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH1, 0xFFF);
  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH2, 0x0);
  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH3, 0x0);
  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH4, 0xFFF);
  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH5, 0x0);
  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH6, 0x0);

  /* Start linear walk at the same time */
  XMC_BCCU_ConcurrentStartLinearWalk(BCCU0, 0x1FF);

  TimerCount = 0;
  dimlv      = 0;
  dimlvbuf   = 91;
  count      = 0;
  state      = OFF;

  packet     = 0; /* The buffer that stores the bits */
  newframe   = 1; /* 1: waiting for a new packet, 0: already in a packet */
  bitend     = 1; /* 1: end of bit, 0: middle of bit */
  bitnumber  = 0; /* No bits in packet yet */

  NVIC_EnableIRQ(CCU40_1_IRQn); /* SR1's interrupt number is 22 */

  XMC_GPIO_SetMode(P0_0, XMC_GPIO_MODE_INPUT_TRISTATE); /* P0.0 is connected to CCU40_CC40IN, so set it to input */

  /* Initialize CCU4 */
  XMC_CCU4_Init(CCU40, XMC_CCU4_SLICE_MCMS_ACTION_TRANSFER_PR_CR); /* Initialize CCU40 kernel */
  XMC_CCU4_EnableClock(CCU40, 0); /* Get the slice out of idle mode */
  XMC_CCU4_StartPrescaler(CCU40); /* Start the prescaler and restore clock to slice */
  XMC_CCU4_SLICE_CaptureInit(CCU40_CC40, &capture_event_config); /* Configure slice as capture mode */
  XMC_CCU4_SLICE_ConfigureEvent(CCU40_CC40, XMC_CCU4_SLICE_EVENT_0, &slice_event_config0); /* init external event */
  XMC_CCU4_SLICE_ConfigureEvent(CCU40_CC40, XMC_CCU4_SLICE_EVENT_1, &slice_event_config1); /* init external event */
  XMC_CCU4_SLICE_Capture0Config(CCU40_CC40, XMC_CCU4_SLICE_EVENT_0); /* External Cap 0 triggered by Event 0 */
  XMC_CCU4_SLICE_Capture1Config(CCU40_CC40, XMC_CCU4_SLICE_EVENT_1); /* External Cap 1 triggered by Event 1 */
  XMC_CCU4_SLICE_EnableMultipleEvents(CCU40_CC40, 0x300); /* Enable event 0 & 1 interrupt */
  XMC_CCU4_SLICE_SetInterruptNode(CCU40_CC40, XMC_CCU4_SLICE_IRQ_ID_EVENT0, XMC_CCU4_SLICE_SR_ID_1); /* Map event 0 to SR1 */
  XMC_CCU4_SLICE_SetInterruptNode(CCU40_CC40, XMC_CCU4_SLICE_IRQ_ID_EVENT1, XMC_CCU4_SLICE_SR_ID_1); /* Map event 1 to SR1 */
  XMC_CCU4_SLICE_StartTimer(CCU40_CC40); /* Start the timer */
  XMC_CCU4_EnableShadowTransfer(CCU40, 0x10000); /* Config the start value for Compare Channel Status */

  XMC_CCU4_SLICE_ClearEvent(CCU40_CC40, XMC_CCU4_SLICE_IRQ_ID_EVENT0); /* Clear event 0 */
  XMC_CCU4_SLICE_ClearEvent(CCU40_CC40, XMC_CCU4_SLICE_IRQ_ID_EVENT1); /* Clear event 1 */

  /* Placeholder for user application code. The while loop below can be replaced with user application code. */
  while(1U)
  {

  }
}

/* 0.01s interrupt base */
void SysTick_Handler(void)
{
  if (count<100)
  {
    count++;
  }
}

/* Edge detection interrupt */
void CCU40_1_IRQHandler(void)
{
  if(XMC_CCU4_SLICE_GetEvent(CCU40_CC40, XMC_CCU4_SLICE_IRQ_ID_EVENT0)) /* Rising edge, event 0 detected */
  {
    TimerCount = XMC_CCU4_SLICE_GetCaptureRegisterValue(CCU40_CC40, 1) & 0x0000FFFF;

	if((newframe == 2) && (TimerCount < 39800) && (TimerCount > 24200))
	{
	  newframe = 0;
	  bitend = 0;
	  bitnumber = 0;
	}
	if(newframe == 0)
	{
	  if((TimerCount < 19400) && (TimerCount > 12600)) /* One chip time, toggle bitend */
	  {
	    bitend ^= 1;
	  }
	  else if((TimerCount < 39800) && (TimerCount > 24200))	/* Two chip time, must be in the middle of a bit */
	  {
	    bitend = 0;
	  }
	  else /* Other unexpected signals like noise */
	  {
	    newframe  = 1;
		bitnumber = 0;
	    bitend    = 1;
      }

	  if(!bitend)
	  {
	    bitnumber++;
		if((bitnumber < 73) && (bitnumber > 64))
		{
		  packet <<= 1; /* Rising edge in the middle, shift in 0(Inverted Logic) */
		}
	  }
	}
	XMC_CCU4_SLICE_ClearEvent(CCU40_CC40, XMC_CCU4_SLICE_IRQ_ID_EVENT0); /* Event 0 detection clear */
  }
  else if(XMC_CCU4_SLICE_GetEvent(CCU40_CC40, XMC_CCU4_SLICE_IRQ_ID_EVENT1)) /* Falling edge, event 1 detected */
  {
    TimerCount = XMC_CCU4_SLICE_GetCaptureRegisterValue(CCU40_CC40, 3) & 0x0000FFFF;

	if((newframe == 1) && (TimerCount > 24200) && (TimerCount < 39800))
	{
	  newframe  = 2;
	  bitend    = 0;
	  bitnumber = 0;
	}
	if(newframe == 0)
	{
	  if((TimerCount < 19400) && (TimerCount > 12600))
	  {
	    bitend ^= 1;
	  }
	  else if((TimerCount < 39800) && (TimerCount > 24200))
	  {
	    bitend  = 0;
	  }
	  else
	  {
		newframe  = 1;
	    bitnumber = 0;
		bitend    = 1;
	  }

	  if(!bitend)
	  {
	    bitnumber++;
		if((bitnumber > 64) && (bitnumber < 73))
		{
		  packet <<= 1;	 /* Falling edge in the middle, shift in 1(Inverted Logic) */
		  packet  |= 0x00000001;
		}
	  }
	}

	if(bitnumber == 72)
	{
	  if(packet == 0x02) /* Right button is pressed */
	  {
	    if(state == ON)
		{ /* Rainbow step right */
		  if(colornumber<=0) colornumber = 23;
		  else colornumber--;

		  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH0, colorArrayR[colornumber]); /* RGB LED 1 */
		  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH7, colorArrayG[colornumber]);
		  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH8, colorArrayB[colornumber]);

		  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH1, colorArrayR[colornumber]); /* RGB LED 2 */
		  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH2, colorArrayG[colornumber]);
		  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH3, colorArrayB[colornumber]);

		  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH4, colorArrayR[colornumber]); /* RGBLED 3 */
		  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH5, colorArrayG[colornumber]);
		  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH6, colorArrayB[colornumber]);

		  /* Start linear walk at the same time */
		  XMC_BCCU_ConcurrentAbortLinearWalk(BCCU0, 0x1FF);
		  XMC_BCCU_ConcurrentStartLinearWalk(BCCU0, 0x1FF);
		}
	  }
	  else if(packet == 0x03) /* Left button is pressed */
	  {
	    if(state == ON)
		{ /* Rainbow step left */
		  colornumber++;
		  if(colornumber >= 24)
		  {
		    colornumber = 0;
		  }

		  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH0, colorArrayR[colornumber]); /* RGB LED 1 */
		  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH7, colorArrayG[colornumber]);
		  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH8, colorArrayB[colornumber]);

		  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH1, colorArrayR[colornumber]); /* RGB LED 2 */
		  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH2, colorArrayG[colornumber]);
		  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH3, colorArrayB[colornumber]);

		  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH4, colorArrayR[colornumber]); /* RGBLED 3 */
		  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH5, colorArrayG[colornumber]);
		  XMC_BCCU_CH_SetTargetIntensity(BCCU0_CH6, colorArrayB[colornumber]);

		  /* Start linear walk at the same time */
		  XMC_BCCU_ConcurrentAbortLinearWalk(BCCU0, 0x1FF);
		  XMC_BCCU_ConcurrentStartLinearWalk(BCCU0, 0x1FF);
		}
	  }
	  else if(packet == 0x04) /* Bottom button is pressed */
	  {
	    if(state == ON)
		{ /* Dim down */
		  if(dimlv > 0)
		  {
		    dimlv = dimlv - 91;
		    XMC_BCCU_DIM_SetTargetDimmingLevel(BCCU0_DE0, dimlv);
		    XMC_BCCU_AbortDimming(BCCU0, 0);
		    XMC_BCCU_StartDimming(BCCU0, 0);
		  }
		}
	  }
	  else if(packet == 0x05) /* Middle button is pressed */
	  {
	    if(count >= 30)	/* enough time elapsed since the last button press */
		{
		  if(state == OFF)
		  { /* Turn ON */
		    state = ON;
		    XMC_BCCU_DIM_SetDimDivider(BCCU0_DE0, 0xA); /* Fine curve, 0.6s full fade time */
			if(dimlvbuf == 0)
			{
			  dimlvbuf = 91;
			}
			dimlv = dimlvbuf;
		    XMC_BCCU_DIM_SetTargetDimmingLevel(BCCU0_DE0, dimlv);
		    XMC_BCCU_AbortDimming(BCCU0, 0);
		    XMC_BCCU_StartDimming(BCCU0, 0);
		  }
		  else
		  { /* Turn OFF */
			state = OFF;
			XMC_BCCU_DIM_SetDimDivider(BCCU0_DE0, 0x5); /* Fine curve, 0.3s full fade time */
			dimlvbuf = XMC_BCCU_DIM_ReadDimmingLevel(BCCU0_DE0);
			dimlv = 0;
		    XMC_BCCU_DIM_SetTargetDimmingLevel(BCCU0_DE0, dimlv);
		    XMC_BCCU_AbortDimming(BCCU0, 0);
		    XMC_BCCU_StartDimming(BCCU0, 0);
		  }
		}
		count = 0;
	  }
	  else if(packet == 0x08) /* Top button is pressed */
	  {
		if(state == ON)
		{ /* Dim up */
		  if(dimlv < 4095)
		  {
		    dimlv = dimlv + 91;
		    XMC_BCCU_DIM_SetTargetDimmingLevel(BCCU0_DE0, dimlv);
		    XMC_BCCU_AbortDimming(BCCU0, 0);
		    XMC_BCCU_StartDimming(BCCU0, 0);
		  }
		}
	  }
	  else
	  {
	    newframe  = 1;
		bitnumber = 0;
		bitend    = 1;
	  }
	  packet = 0;
	}

	if(bitnumber == 128) /* Packet fully detected and received */
	{
	  newframe  = 1;
	  bitnumber = 0;
	  bitend    = 1;
	}

	XMC_CCU4_SLICE_ClearEvent(CCU40_CC40, XMC_CCU4_SLICE_IRQ_ID_EVENT1); /* Event 1 detection clear */
  }
}
